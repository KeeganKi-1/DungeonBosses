package code;

/**
 * Class ArcadeDemo
 * This class contains demos of many of the things you might
 * want to use to make an animated arcade game.
 * 
 * Adapted from the AppletAE demo from years past. 
 */

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.sound.sampled.Clip;


public class ArcadeDemo extends AnimationPanel 
{
    Player player = new Player();
    private boolean shouldGoUp =false;
    private boolean shouldGoDown =false;
    private boolean shouldGoLeft =false;
    private boolean shouldGoRight =false;
    ArrayList<Projectile> laserArray = new ArrayList<>();
    private int laserSpeed = 6;
    private Room1 currentRoom = new Room1();
    //Constructor
    //-------------------------------------------------------
    public ArcadeDemo()
    {   //Enter the name and width and height.  
        super("ArcadeDemo", 700+23, 700+57);
    }
       
    //The renderFrame method is the one which is called each time a frame is drawn.
    //-------------------------------------------------------
    protected void renderFrame(Graphics g) 
    {


        g.setColor(Color.BLACK);
        g.fillRect(0, 0, 700, 700);
        
        currentRoom.drawEnemies(g, this);
        if(frameNumber%60 ==0){
            currentRoom.fireEnemyLasers(this);
        }

        if(shouldGoUp)
            player.moveUp();
        if(shouldGoLeft)
            player.moveLeft();
        if(shouldGoDown)
            player.moveDown();
        if(shouldGoRight)
            player.moveRight();
        g.drawImage(playerImage, player.getX(), player.getY(), this);
        for(int i = 0; i<laserArray.size();i++){
            if(laserArray.get(i).isFrozen()){
                laserArray.remove(i);
            }
            g.setColor(Color.YELLOW);
            if(laserArray.size()>i){
            g.fillRect(laserArray.get(i).getX(), laserArray.get(i).getY(), laserArray.get(i).WIDTH,laserArray.get(i).HEIGHT);
            laserArray.get(i).animate();
            }

        }
        for(int i =0; i<laserArray.size(); i++){
            for(int j =0; j<currentRoom.enemyArray.size(); j++){
             if(laserArray.size()>i){  
            if(inHitboxBounds(currentRoom.enemyArray.get(j).hitbox, laserArray.get(i).getX(), laserArray.get(i).getY(), laserArray.get(i).WIDTH, laserArray.get(i).HEIGHT)){
                if(laserArray.get(i) instanceof Projectile){
                    
                    currentRoom.enemyArray.get(j).hp-=laserArray.get(i).damage;
                    laserArray.remove(i);
                }
                
            }
            } 
        }
    }
    for(int i =0; i<currentRoom.enemyArray.size(); i++){
        if(currentRoom.enemyArray.get(i).hp<=0){
            currentRoom.enemyArray.remove(i);
        }
    }
        
    }
    
    public boolean inHitboxBounds(Hitbox hitbox, int x, int y, int width,int height){
        if((x >= hitbox.x && x<=hitbox.x+hitbox.HEIGHT) && (y >= hitbox.y && y<=hitbox.y+hitbox.WIDTH)){
        return true;
    }
        if( (x+width >= hitbox.x && x+width<=hitbox.x+hitbox.HEIGHT) && (y+height >= hitbox.y && y+height<=hitbox.y+hitbox.WIDTH)){
        return true;
    }
        return false;
    }

    public int determineLaserStartX(int goalX, int startX){
        if(startX-goalX<50){
            return startX+50;
        }
        else{
            return startX;
        }
    }
    public int determineLaserStartY(int goalY, int startY){
        if(startY-goalY<50){
            return startY+50;
        }
        else{
            return startY;
        }
    }

    //-------------------------------------------------------
    //Respond to Mouse Events
    //-------------------------------------------------------
    public void mouseClicked(MouseEvent e)  
    { 
        
    }
    
    //-------------------------------------------------------
    //Respond to Keyboard Events
    //-------------------------------------------------------
    public void keyTyped(KeyEvent e) 
    {
        
    }
    
    public void keyPressed(KeyEvent e)
    {
        int v = e.getKeyCode();
        if(v == KeyEvent.VK_W ){
            shouldGoUp =true;
        }
        if(v == KeyEvent.VK_S){
            shouldGoDown = true;
        }
        if(v == KeyEvent.VK_A ){
            shouldGoLeft = true;
        }
        if(v == KeyEvent.VK_D  ){
            shouldGoRight =true;
        }
        
        
    }

    public void keyReleased(KeyEvent e)
    {
        int v = e.getKeyCode();
        if(v == KeyEvent.VK_W ){
            shouldGoUp =false;
        }
        if(v == KeyEvent.VK_S){
            shouldGoDown = false;
        }
        if(v == KeyEvent.VK_A ){
            shouldGoLeft = false;
        }
        if(v == KeyEvent.VK_D  ){
            shouldGoRight =false;
        }
        if(v== KeyEvent.VK_SHIFT){
            int  startY = determineLaserStartY(mouseY, player.getY());
            int startX = determineLaserStartX(mouseX,player.getX());
            int xVelocity = (int) ((int) laserSpeed*Math.cos(Math.atan2(mouseY-startY, mouseX-startX)));
            int yVelocity = (int) ((int) laserSpeed*Math.sin(Math.atan2(mouseY-startY, mouseX-startX)));
            Projectile tempProj = new Projectile(player.getLaserDamage());
            tempProj.fireWeapon(startX,startY,xVelocity,yVelocity);
            laserArray.add(tempProj);

        }
        
    }
    
    
    //-------------------------------------------------------
    //Initialize Graphics
    //-------------------------------------------------------
//-----------------------------------------------------------------------
/*  Image section... 
 *  To add a new image to the program, do three things.
 *  1.  Make a declaration of the Image by name ...  Image imagename;
 *  2.  Actually make the image and store it in the same directory as the code.
 *  3.  Add a line into the initGraphics() function to load the file. 
//-----------------------------------------------------------------------*/
    Image ballImage;        
    Image starImage;
    Image playerImage;
    Image background;
    Image lvl1Enemy;
    public void initGraphics() 
    {      
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        
        ballImage = toolkit.getImage("src/images/ball.gif");
        starImage = toolkit.getImage("src/images/star.gif");
        playerImage = toolkit.getImage("src/images/MC.png").getScaledInstance(50, 50, 0);
        background = toolkit.getImage("src/images/background.png").getScaledInstance(700, 700,0);
        lvl1Enemy = toolkit.getImage("src/images/ENM1.png").getScaledInstance(50, 50, 0);
    } //--end of initGraphics()--
    
    //-------------------------------------------------------
    //Initialize Sounds
    //-------------------------------------------------------
//-----------------------------------------------------------------------
/*  Music section... 
 *  To add music clips to the program, do four things.
 *  1.  Make a declaration of the AudioClip by name ...  AudioClip clipname;
 *  2.  Actually make/get the .wav file and store it in the same directory as the code.
 *  3.  Add a line into the initMusic() function to load the clip. 
 *  4.  Use the play(), stop() and loop() functions as needed in your code.
//-----------------------------------------------------------------------*/
    Clip themeMusic;
    Clip bellSound;
    
    public void initMusic() 
    {
        themeMusic = loadClip("src/audio/background.wav");
        bellSound = loadClip("src/audio/ding.wav");
        if(themeMusic != null)
//            themeMusic.start(); //This would make it play once!
            themeMusic.loop(50); //This would make it loop 2 times.
    }

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
}//--end of ArcadeDemo class--

