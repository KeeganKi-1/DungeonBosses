package code;

/**
 * Class ArcadeDemo
 * This class contains demos of many of the things you might
 * want to use to make an animated arcade game.
 * 
 * Adapted from the AppletAE demo from years past. 
 */

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.concurrent.ForkJoinTask;

import javax.sound.sampled.Clip;

public class ArcadeDemo extends AnimationPanel {
    Player player = new Player();
    boolean giveOneUp = true;
    private boolean shouldGoUp = false;
    private boolean shouldGoDown = false;
    private boolean shouldGoLeft = false;
    private boolean shouldGoRight = false;
    private boolean shouldFire = false;
    private boolean buy = false;
    boolean startAnew = false;
    int lives = 0;
    String choice1;
    String choice2;
    String choice3;
    ArrayList<Projectile> laserArray = new ArrayList<>();
    public int laserSpeed = 6;
    public double fireRate = 2;
    public Room1 currentRoom = new Room1();
    int goldIncrease = 0;
    int gold = 100;
    int timeTillBoss = 20;
    int turnNumber = 1;
    ArcadeRunner runner;

    // Constructor
    // -------------------------------------------------------
    public ArcadeDemo(ArcadeRunner runner) { // Enter the name and width and height.
        super("ArcadeDemo", 700 + 23 - 9, 700 + 57 - 18);
        this.runner = runner;
    }

    // The renderFrame method is the one which is called each time a frame is drawn.
    // -------------------------------------------------------
    protected void renderFrame(Graphics g) {
        if (lives > 0) {
            //draws the background
            for (int i = 0; i < 14; i++) {
                for (int j = 0; j < 14; j++) {
                    g.drawImage(background, i * 50, j * 50, this);
                }
            }
            //sets room to final boss
            if(turnNumber == timeTillBoss){
                if(!(currentRoom instanceof BossRoom))
                currentRoom = new BossRoom();
            }
            // draws the doors
            g.setColor(Color.BLACK);
            g.fillRect(250, 0, 200, 50);
            g.fillRect(0, 250, 50, 200);
            g.fillRect(650, 250, 50, 200);
            determineChoices();
            g.setColor(Color.YELLOW);
            g.setFont(new Font("Times New Roman", 1, 40));
            g.drawString(choice1, 340, 40);
            g.drawString(choice2, 10, 350);
            g.drawString(choice3, 660, 350);
            //draws the shop room
            if (currentRoom instanceof Shop) {

                g.setColor(Color.BLACK);
                g.fillRect(150, 350, 100, 50);
                g.fillRect(300, 350, 100, 50);
                g.fillRect(450, 350, 100, 50);
                g.setColor(Color.RED);
                g.fillRect(200, 275, 300, 50);
                g.setColor(Color.YELLOW);
                g.setFont(new Font("Times New Roman", 1, 18));
                g.drawString(currentRoom.text1 + "", 175, 375);
                g.drawString(currentRoom.text2 + "", 325, 375);
                g.drawString(currentRoom.text3 + "", 475, 375);
                g.drawString(currentRoom.price1 + "", 175, 425);
                g.drawString(currentRoom.price2 + "", 325, 425);
                g.drawString(currentRoom.price3 + "", 475, 425);

            }
            //changes rooms
            if (checkLeaving() != 0 && (currentRoom.enemyArray.size() == 0)) {
                turnNumber++;
                int check = checkLeaving();
                player.setX(350);
                player.setY(650);
laserArray.clear();
                //sets the room when the player goes through the doors and gives gold
                if (check == 1) {

                    if (currentRoom.choice1 == 0) {
                        currentRoom = new Room1();
                        gold += (100 + goldIncrease);
                    } else if (currentRoom.choice1 == 1) {
                        currentRoom = new Room2();
                        gold += (200 + goldIncrease);
                    } else if (currentRoom.choice1 == 2) {
                        gold += (300 + goldIncrease);
                        currentRoom = new Room3();
                    } else if (currentRoom.choice1 == 3) {
                        gold += (1 + goldIncrease);
                        currentRoom = new Shop();
                    }
                    else if (currentRoom.choice1 == 8) {
                        gold += (1 + goldIncrease);
                        currentRoom = new OneUp(this);
                    }
                } else if (check == 2) {
                    if (currentRoom.choice2 == 0) {
                        currentRoom = new Room1();
                        gold += (100 + goldIncrease);
                    } else if (currentRoom.choice2 == 1) {
                        currentRoom = new Room2();
                        gold += (200 + goldIncrease);
                    } else if (currentRoom.choice2 == 2) {
                        gold += (300 + goldIncrease);
                        currentRoom = new Room3();
                    } else if (currentRoom.choice2 == 3) {
                        gold += (1 + goldIncrease);
                        currentRoom = new Shop();
                    }
                    else if (currentRoom.choice2 == 4) {
                        gold += (1 + goldIncrease);
                        currentRoom = new OneUp(this);
                    }
                } else if (check == 3) {
                    if (currentRoom.choice3 == 0) {
                        currentRoom = new Room1();
                        gold += (100 + goldIncrease);
                    } else if (currentRoom.choice3 == 1) {
                        currentRoom = new Room2();
                        gold += (200 + goldIncrease);
                    } else if (currentRoom.choice3 == 2) {
                        gold += (300 + goldIncrease);
                        currentRoom = new Room3();
                    } else if (currentRoom.choice3 == 3) {
                        gold += (1 + goldIncrease);
                        currentRoom = new Shop();
                    }
                    else if (currentRoom.choice3 == 4) {
                        gold += (1 + goldIncrease);
                        currentRoom = new OneUp(this);
                    }
                }

            }
            //Buys something 
            if (currentRoom instanceof Shop) {

                if (buy) {

                    if (player.hitbox.intersects(new Rectangle(150, 350, 100, 50))) {

                        currentRoom.determineBuyAction1(this);
                    }
                    if (player.hitbox.intersects(new Rectangle(300, 350, 100, 50))) {
                        currentRoom.determineBuyAction2(this);
                    }
                    if (player.hitbox.intersects(new Rectangle(450, 350, 100, 50))) {
                        currentRoom.determineBuyAction3(this);
                    }
                    buy = false;
                }
            }
            //GIves player a one up
            if (currentRoom instanceof OneUp && giveOneUp) {

                if (currentRoom.getsOneUp(g, this)) {
                    lives++;
                    giveOneUp = false;

                }
            }
            //Draws the enemies
            currentRoom.drawEnemies(g, this);
            //Makes the enemies fire every thirty framse
            if (frameNumber % 30 == 0) {
                for (int i = 0; i < currentRoom.getHowManyToFire(); i++) {
                    currentRoom.fireEnemyLasers(this);
                }
            }
            //Fires the lasers from the player
            if (shouldFire && frameNumber % (int)(24 / fireRate) == 0) {
                
                int startY = determineLaserStartY(mouseY, player.getY());
                int startX = determineLaserStartX(mouseX, player.getX());
                double xVelocity =  ( laserSpeed * Math.cos(Math.atan2(mouseY - startY, mouseX - startX)));
                double yVelocity = (laserSpeed * Math.sin(Math.atan2(mouseY - startY, mouseX - startX)));
                Projectile tempProj = new Projectile(player.getLaserDamage());
                tempProj.fireWeapon(startX, startY, xVelocity, yVelocity);
                laserArray.add(tempProj);
            }
            //Does player movement
            if (shouldGoUp)
                player.moveUp();
            if (shouldGoLeft)
                player.moveLeft();
            if (shouldGoDown)
                player.moveDown();
            if (shouldGoRight)
                player.moveRight();
            //Draws player
            g.drawImage(playerImage, player.getX(), player.getY(), this);
            //Draw and animates the lasers
            for (int i = 0; i < laserArray.size(); i++) {
                if (laserArray.get(i).isFrozen()) {
                    laserArray.remove(i);
                }
                g.setColor(Color.YELLOW);
                if (laserArray.size() > i) {
                    g.fillRect(laserArray.get(i).getX(), laserArray.get(i).getY(), laserArray.get(i).WIDTH,
                            laserArray.get(i).HEIGHT);
                    laserArray.get(i).animate();
                }

            }
            //Checks if any of the aliens are being hit and hurts them
            for (int i = 0; i < laserArray.size(); i++) {
                for (int j = 0; j < currentRoom.enemyArray.size(); j++) {
                    if (laserArray.size() > i) {
                        
                        if (laserArray.get(i).getRect().intersects(currentRoom.enemyArray.get(j).hitbox)) {
                            
                            if (!(laserArray.get(i) instanceof AlienProjectile)) {
                                   
                                currentRoom.enemyArray.get(j).hp -= laserArray.get(i).damage;
                                laserArray.remove(i);
                            }

                        }
                    }
                }
            }
            //Checks if one of the alien laser should hurt the player and removes it
            for (int i = 0; i < laserArray.size(); i++) {
                Projectile current = laserArray.get(i);
                if (current.getRect().intersects(player.hitbox)) {
                    if (laserArray.get(i) instanceof AlienProjectile) {
                        player.hp -= current.damage;
                        laserArray.remove(i);

                    }
                }
            }
            //Kills the player and brings him back to the centre
            if (player.hp <= 0) {
                player = new Player(player.getLaserDamage(), player.maxHp, player.speed);
                lives--;
            }
            for (int i = 0; i < currentRoom.enemyArray.size(); i++) {
                if (currentRoom.enemyArray.get(i).hp <= 0) {
                    currentRoom.enemyArray.remove(i);
                }
            }
            //Draws all the stats you want to know
            g.setColor(Color.YELLOW);
            g.setFont(new Font("Comic Sans", 1, 20));
            g.drawString(player.hp + "/" + player.maxHp, 0, 675);
            g.drawString("Gold: " + gold, 590, 675);
            g.drawString("Room: " + turnNumber + "/" + timeTillBoss, 0, 30);
            g.drawString("Lives: " + lives, 590, 30);
        } 
        //Retarts the room when you die
        else {
            g.drawImage(deathScreen,0,0,this);
            if (lives == 0 && startAnew) {
                player = new Player();
                shouldGoUp = false;
                shouldGoDown = false;
                shouldGoLeft = false;
                shouldGoRight = false;
                shouldFire = false;
                buy = false;
                startAnew = false;
                lives = 3;

                laserArray = new ArrayList<>();
                laserSpeed = 6;
                fireRate = 1;
                currentRoom = new Room1();
                goldIncrease = 0;
                gold = 100;
                timeTillBoss = 20;
                turnNumber = 1;
                startAnew = false;

            }
        }
    }

    public boolean inHitboxBounds(Hitbox hitbox, int x, int y, int width, int height) {
        if ((x >= hitbox.x && x <= hitbox.x + hitbox.WIDTH) && (y >= hitbox.y && y <= (hitbox.y + hitbox.HEIGHT))) {
            return true;
        }
        if ((x + width >= hitbox.x && x + width <= hitbox.x + hitbox.WIDTH)
                && (y + height >= hitbox.y && y + height <= (hitbox.y + hitbox.HEIGHT))) {
            return true;
        }

        return false;
    }

    public int determineLaserStartX(int goalX, int startX) {
        if (startX - goalX < 50) {
            return startX + 50;
        } else {
            return startX;
        }
    }

    public int determineLaserStartY(int goalY, int startY) {
        if (startY - goalY < 50) {
            return startY + 50;
        } else {
            return startY;
        }

    }

    public void determineChoices() {
        switch (currentRoom.choice1) {
            case 0:
                choice1 = "I";
                break;
            case 1:
                choice1 = "II";
                break;
            case 2:
                choice1 = "III";
                break;
            case 3:
                choice1 = "Shop";
                break;
            case 8:
                choice1 = "+1";

        }
        switch (currentRoom.choice2) {
            case 0:
                choice2 = "I";
                break;
            case 1:
                choice2 = "II";
                break;
            case 2:
                choice2 = "III";
                break;
            case 3:
                choice2 = "Shop";
                break;
            case 4:
                choice2 = "+1";
            
        }
        switch (currentRoom.choice3) {
            case 0:
                choice3 = "I";
                break;
            case 1:
                choice3 = "II";
                break;
            case 2:
                choice3 = "III";
                break;
            case 3:
                choice3 = "Shop";
                break;
            case 4:
                choice3 = "+1";

        }

    }

    public int checkLeaving() {
        if (player.hitbox.intersects(new Rectangle(250, 0, 200, 50)))
            return 1;
        if (player.hitbox.intersects(new Rectangle(0, 250, 50, 200)))
            return 2;
        if (player.hitbox.intersects(new Rectangle(650, 250, 50, 200)))
            return 3;
        else
            return 0;

    }

    // -------------------------------------------------------
    // Respond to Mouse Events
    // -------------------------------------------------------
    public void mouseClicked(MouseEvent e) {

    }

    // -------------------------------------------------------
    // Respond to Keyboard Events
    // -------------------------------------------------------
    public void keyTyped(KeyEvent e) {

    }

    public void keyPressed(KeyEvent e) {
        int v = e.getKeyCode();
        if (v == KeyEvent.VK_W) {
            shouldGoUp = true;
        }
        if (v == KeyEvent.VK_S) {
            shouldGoDown = true;
        }
        if (v == KeyEvent.VK_A) {
            shouldGoLeft = true;
        }
        if (v == KeyEvent.VK_D) {
            shouldGoRight = true;
        }
        if (v == KeyEvent.VK_SPACE) {
            shouldFire = true;
        }

    }

    public void keyReleased(KeyEvent e) {
        int v = e.getKeyCode();
        if (v == KeyEvent.VK_W) {
            shouldGoUp = false;
        }
        if (v == KeyEvent.VK_S) {
            shouldGoDown = false;
        }
        if (v == KeyEvent.VK_A) {
            shouldGoLeft = false;
        }
        if (v == KeyEvent.VK_D) {
            shouldGoRight = false;
        }
        
        if (v == KeyEvent.VK_SPACE) {

            shouldFire = false;
        }
        if (v == KeyEvent.VK_Q) {
            buy = true;
        }
        if (v == KeyEvent.VK_ENTER) {
            startAnew = true;
        }

    }

    // -------------------------------------------------------
    // Initialize Graphics
    // -------------------------------------------------------
    // -----------------------------------------------------------------------
    /*
     * Image section...
     * To add a new image to the program, do three things.
     * 1. Make a declaration of the Image by name ... Image imagename;
     * 2. Actually make the image and store it in the same directory as the code.
     * 3. Add a line into the initGraphics() function to load the file.
     * //-----------------------------------------------------------------------
     */
    Image ballImage;
    Image starImage;
    Image playerImage;
    Image background;
    Image lvl1Enemy;
    Image boss;
    Image deathScreen;
    public void initGraphics() {
        Toolkit toolkit = Toolkit.getDefaultToolkit();

        ballImage = toolkit.getImage("src/images/ball.gif");
        starImage = toolkit.getImage("src/images/star.gif");
        playerImage = toolkit.getImage("src/images/MC.png").getScaledInstance(50, 50, 0);
        background = toolkit.getImage("src/images/back ground.png").getScaledInstance(50, 50, 0);
        lvl1Enemy = toolkit.getImage("src/images/ENM1.png").getScaledInstance(50, 50, 0);
        boss = toolkit.getImage("src/images/Boss.png").getScaledInstance(100, 100, 0);
        deathScreen = toolkit.getImage("src/images/deathscreen.png").getScaledInstance(700, 700, 0);
    } // --end of initGraphics()--

    // -------------------------------------------------------
    // Initialize Sounds
    // -------------------------------------------------------
    // -----------------------------------------------------------------------
    /*
     * Music section...
     * To add music clips to the program, do four things.
     * 1. Make a declaration of the AudioClip by name ... AudioClip clipname;
     * 2. Actually make/get the .wav file and store it in the same directory as the
     * code.
     * 3. Add a line into the initMusic() function to load the clip.
     * 4. Use the play(), stop() and loop() functions as needed in your code.
     * //-----------------------------------------------------------------------
     */
    Clip themeMusic;
    Clip bellSound;

    public void initMusic() {
        themeMusic = loadClip("src/audio/background.wav");
        bellSound = loadClip("src/audio/ding.wav");
        if (themeMusic != null)
            // themeMusic.start(); //This would make it play once!
            themeMusic.loop(50); // This would make it loop 2 times.
    }

    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
}// --end of ArcadeDemo class--
