package code;

public class Room3 extends Room1 {
    
   //fills the room with enemies
    @Override
    public void fillEnemies() {
        for(int i = 0; i<10; i++){
            int x = (int) ((int) 650*Math.random());
        int y = (int) ((int) 400*Math.random());
            enemyArray.add(new Enemy(x, y, 12, 2, 2, 14));
        }
    }
}
