package code;

public class Hitbox {
    int x;
    int y;
    int WIDTH;
    int HEIGHT;

    public int getX() {
        return this.x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return this.y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public Hitbox(int x, int y,int width,int height){
        this.x =x;
        this.y = y;
        this.HEIGHT = height;
        this.WIDTH = width;
    }

    
}
