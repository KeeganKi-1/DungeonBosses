package code;

import java.awt.Graphics;

public class Shop extends Room1 {
    
    

    
// initiizes the items text and prices
    public Shop(){
       
        item1 = (int)Math.round(Math.random()*8);
        item2 = (int)Math.round(Math.random()*8);
        item3 = (int)Math.round(Math.random()*8);
        determineText();
        determinePrice();
        
        
    }
    
    @Override
    public void fillEnemies() {
        
    }
    
    @Override
    public void drawEnemies(Graphics g, ArcadeDemo demo) {
        
    }
    @Override
    public void fireEnemyLasers(ArcadeDemo demo) {
        
    }
    //determines what should happen if the player buys the first option
    public void determineBuyAction1(ArcadeDemo demo){
        
       int gold = demo.gold;
        switch(item1){
            
            case 0:
            if(gold>=100){
                gold-=100;
            demo.player.hp+=10;
            if(demo.player.hp>demo.player.maxHp)
            demo.player.hp = demo.player.maxHp;
            }
            break;
            case 1:
            if(gold>=400){
                gold-=400;
            demo.player.setLaserDamage(demo.player.getLaserDamage()+0.5);
            }
            break;
            case 2:
            if(gold>=200){
                gold-=200;
            demo.laserSpeed*=2;
            }
            break;
            case 3:
            if(gold>=300){
                gold-=300;
            demo.fireRate*=1.3;
            if(demo.fireRate>16)
            demo.fireRate = 16;
            }
            break;
            case 4:
            if(gold>=400){
                gold-=400;
            demo.player.maxHp+=10;
            demo.player.hp = demo.player.maxHp;
            }
            break;
            case 5:
            if(gold>=300)
            {
                gold-=300;
            demo.player.speed*=1.5;
            }
            break;
            case 6:
            if(gold>=500){
                gold-=500;
            demo.goldIncrease+=50;
            }
            break;
            case 7:
            if(gold>=600){
                gold-=600;
            demo.timeTillBoss +=5;
            }
            break;
            case 8:
            if(gold>=100){
                gold-=100;
            demo.currentRoom = new Shop();
            break;
            }
            
        }
        
            demo.gold = gold;
    }
     //determines what should happen if the player buys the second option
    public void determineBuyAction2(ArcadeDemo demo){
        int gold = demo.gold;
        switch(item2){
            
            case 0:
            if(gold>=100){
                gold-=100;
            demo.player.hp+=10;
            if(demo.player.hp>demo.player.maxHp)
            demo.player.hp = demo.player.maxHp;
            
            }
            break;
            case 1:
            if(gold>=400){
                gold-=400;
            demo.player.setLaserDamage(demo.player.getLaserDamage()+0.5);
            }
            break;
            case 2:
            if(gold>=200){
                gold-=200;
            demo.laserSpeed*=2;
            }
            break;
            case 3:
            if(gold>=300){
                gold-=300;
            demo.fireRate*=1.3;
            if(demo.fireRate>16)
            demo.fireRate = 16;
            }
            break;
            case 4:
            if(gold>=400){
                gold-=400;
            demo.player.maxHp+=10;
            demo.player.hp = demo.player.maxHp;
            }
            break;
            case 5:
            if(gold>=300)
            {
                gold-=300;
            demo.player.speed*=1.5;
            }
            break;
            case 6:
            if(gold>=500){
                gold-=500;
            demo.goldIncrease+=50;
            }
            break;
            case 7:
            if(gold>=600){
                gold-=600;
            demo.timeTillBoss +=5;
            }
            break;
            case 8:
            if(gold>=100){
                gold-=100;
            demo.currentRoom = new Shop();
            break;
            }
        }
            demo.gold = gold;
    }
     //determines what should happen if the player buys the third option
    public void determineBuyAction3(ArcadeDemo demo){
        int gold = demo.gold;
        switch(item3){
            
            case 0:
            if(gold>=100){
                gold-=100;
            demo.player.hp+=10;
            if(demo.player.hp>demo.player.maxHp)
            demo.player.hp = demo.player.maxHp;
            }
            break;
            case 1:
            if(gold>=400){
                gold-=400;
            demo.player.setLaserDamage(demo.player.getLaserDamage()+0.5);
            }
            break;
            case 2:
            if(gold>=200){
                gold-=200;
            demo.laserSpeed*=2;
            }
            break;
            case 3:
            if(gold>=300){
                gold-=300;
            demo.fireRate*=1.3;
            if(demo.fireRate>16)
            demo.fireRate = 16;
            }
            break;
            case 4:
            if(gold>=400){
                gold-=400;
            demo.player.maxHp+=10;
            demo.player.hp = demo.player.maxHp;
            }
            break;
            case 5:
            if(gold>=300)
            {
                gold-=300;
            demo.player.speed*=1.5;
            }
            break;
            case 6:
            if(gold>=500){
                gold-=500;
            demo.goldIncrease+=50;
            }
            break;
            case 7:
            if(gold>=600){
                gold-=600;
            demo.timeTillBoss +=5;
            }
            break;
            case 8:
            if(gold>=100){
                gold-=100;
            demo.currentRoom = new Shop();
            break;
            }
            
        }
        demo.gold = gold;
    }
    //determines the prices
    public void determinePrice(){
        switch(item1){
            case 0:
            price1 =100;
            break;
            case 1:
            price1 =400;
            break;
            case 2:
            price1 =200;
            break;
            case 3:
            price1 =300;
            break;
            case 4:
            price1 =400;
            break;
            case 5:
            price1 =300;
            break;
            case 6:
            price1 =500;
            break;
            case 7:
            price1 =600;
            break;
            case 8:
            price1 =100;
            break;
        }
        switch(item2){
            case 0:
            price2 =100;
            break;
            case 1:
            price2 =400;
            break;
            case 2:
            price2 =200;
            break;
            case 3:
            price2 =300;
            break;
            case 4:
            price2 =400;
            break;
            case 5:
            price2 =300;
            break;
            case 6:
            price2 =500;
            break;
            case 7:
            price2 =600;
            break;
            case 8:
            price2 =100;
            break;
        }
        switch(item3){
            case 0:
            price3 =100;
            break;
            case 1:
            price3 =400;
            break;
            case 2:
            price3 =200;
            break;
            case 3:
            price3 =300;
            break;
            case 4:
            price3 =400;
            break;
            case 5:
            price3 =300;
            break;
            case 6:
            price3 =500;
            break;
            case 7:
            price3 =600;
            break;
            case 8:
            price3 =100;
            break;
        }
    }
    //determines the text for each option
    public void determineText(){
        switch(item1){
            case 0:
            text1 = "Heal +10";
            break;
            case 1:
            text1 = "Laser Damage +0.5";
            break;
            case 2:
            text1 = "Laser Speed *2";
            break;
            case 3:
            text1 = "Fire Rate *1.3";
            break;
            case 4:
            text1 = "Max Hp +10";
            break;
            case 5:
            text1 = "Speed *1.5";
            break;
            case 6:
            text1 = "Gold Per Room +50";
            break;
            case 7:
            text1 = "Rounds Till Boss +5";
            break;
            case 8:
            text1 = "Reroll";
            break;
            

        }
        switch(item2){
            case 0:
            text2 = "Heal +10";
            break;
            case 1:
            text2 = "Laser Damage +0.5";
            break;
            case 2:
            text2 = "Laser Speed *2";
            break;
            case 3:
            text2 = "Fire Rate *1.3";
            break;
            case 4:
            text2 = "Max Hp +10";
            break;
            case 5:
            text2 = "Speed *1.5";
            break;
            case 6:
            text2 = "Gold Per Room +50";
            break;
            case 7:
            text2 = "Rounds Till Boss +5";
            break;
            case 8:
            text2 = "Reroll";
            break;
            

        }
        switch(item3){
            case 0:
            text3 = "Heal +10";
            break;
            case 1:
            text3 = "Laser Damage +0.5";
            break;
            case 2:
            text3 = "Laser Speed *2";
            break;
            case 3:
            text3 = "Fire Rate *1.3";
            break;
            case 4:
            text3 = "Max Hp +10";
            break;
            case 5:
            text3 = "Speed *1.5";
            break;
            case 6:
            text3 = "Gold Per Room +50";
            break;
            case 7:
            text3 = "Rounds Till Boss +5";
            break;
            case 8:
            text3 = "Reroll";
            break;
            

        }
    }
    
}
