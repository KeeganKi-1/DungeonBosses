package code;

import java.awt.Rectangle;

public class Boss extends Enemy {
    // creates a boss which is a large moving enemy
    public Boss(int x, int y, int hp, int laserdmg, int characterSpeed,int laserSpeed){
        super(x, y, hp, laserdmg, characterSpeed, laserSpeed);
        this.hitbox = new Rectangle(100,100);
    }
   
}
