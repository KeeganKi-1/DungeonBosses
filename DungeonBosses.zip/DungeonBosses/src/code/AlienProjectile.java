package code;

public class AlienProjectile extends Projectile{

    public AlienProjectile(int damage) {
        super(damage);
        //TODO Auto-generated constructor stub
    }
    
}
