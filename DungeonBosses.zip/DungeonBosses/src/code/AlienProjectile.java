package code;

public class AlienProjectile extends Projectile{
// creates a projectile the same as a normal projectile but lets me know it came from an alien
    public AlienProjectile(int damage) {
        super(damage);
        //TODO Auto-generated constructor stub
    }
    
}
