package code;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JPanel;

public class Enemy {

     int hp;
    private int laserDamage;
    private int characterSpeed;
    int laserSpeed;
    private int x;
    private int y;
    private int HEIGHT = 50;
    private int WIDTH = 50;
    Hitbox hitbox;

    public int getHp() {
        return this.hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getLaserDamage() {
        return this.laserDamage;
    }

    public void setLaserDamage(int laserDamage) {
        this.laserDamage = laserDamage;
    }

    public int getCharacterSpeed() {
        return this.characterSpeed;
    }

    public void setCharacterSpeed(int characterSpeed) {
        this.characterSpeed = characterSpeed;
    }

    public int getLaserSpeed() {
        return this.laserSpeed;
    }

    public void setLaserSpeed(int laserSpeed) {
        this.laserSpeed = laserSpeed;
    }

    public int getX() {
        return this.x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return this.y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public Enemy(int x, int y, int hp, int laserdmg, int characterSpeed,int laserSpeed){
        this.x =x;
        this.y = y;
        this.hp=hp;
        laserDamage=laserdmg;
        this.characterSpeed = characterSpeed;
        this.laserSpeed = laserSpeed;
        hitbox = new Hitbox(x, y,WIDTH,HEIGHT);
    }

    public void takeDamage(int damage){
        hp-=damage;
    }


    
}
