package code;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JPanel;
import java.awt.Rectangle;

public class Enemy {

     double hp;
    private int laserDamage;
    private int characterSpeed;
    int laserSpeed;
    private int x;
    private int y;
    private int HEIGHT = 50;
    private int WIDTH = 50;
    boolean moveLeft = true;
    boolean moveDown =true;
    Rectangle hitbox;
//returns hp
    public double getHp() {
        return this.hp;
    }
//sets hp
    public void setHp(int hp) {
        this.hp = hp;
    }
//returns the laser damage
    public int getLaserDamage() {
        return this.laserDamage;
    }
//set the laser damage
    public void setLaserDamage(int laserDamage) {
        this.laserDamage = laserDamage;
    }
//returns the character speed
    public int getCharacterSpeed() {
        return this.characterSpeed;
    }
//sets the character speed
    public void setCharacterSpeed(int characterSpeed) {
        this.characterSpeed = characterSpeed;
    }
//returns the laser speed
    public int getLaserSpeed() {
        return this.laserSpeed;
    }
// sets the laser speed
    public void setLaserSpeed(int laserSpeed) {
        this.laserSpeed = laserSpeed;
    }
//returns the x
    public int getX() {
        return this.x;
    }
    // moves them
    public void move(){
        
        if(getX()<600 && getX()>100){
            if(moveLeft){
            setX(getX()-getCharacterSpeed());
            hitbox.x=getX();
            }
            else{
                setX(getX()+getCharacterSpeed()); 
                hitbox.x=getX(); 
            }
        }
        else{
            moveLeft = !moveLeft;
            
                if(moveLeft){
                setX(getX()-getCharacterSpeed());
                hitbox.x=getX();
                }
                else{
                    
                    setX(getX()+getCharacterSpeed());  
                    hitbox.x=getX();
                }
            
        }
        
        if(getY()>0 && getY()<400){
            if(moveDown){
            setY(getY()+getCharacterSpeed());
            hitbox.y = getY();
            }
            else{
            setY(getY()-getCharacterSpeed());
            hitbox.y = getY();
            }
        }
        else{
            moveDown = !moveDown;
            if(moveDown){
            setY(getY()+getCharacterSpeed());
            hitbox.y = getY();
            }
            else{
            setY(getY()-getCharacterSpeed());
            hitbox.y = getY();
            }
        }
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return this.y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public Enemy(int x, int y, int hp, int laserdmg, int characterSpeed,int laserSpeed){
        this.x =x;
        this.y = y;
        this.hp=hp;
        laserDamage=laserdmg;
        this.characterSpeed = characterSpeed;
        this.laserSpeed = laserSpeed;
        hitbox = new Rectangle(x, y,WIDTH,HEIGHT);
    }

    public void takeDamage(int damage){
        hp-=damage;
    }


    
}
