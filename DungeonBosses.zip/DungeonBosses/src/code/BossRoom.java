package code;
import java.awt.Graphics;
public class BossRoom extends Room1 {
    @Override
    public void fillEnemies() {
        for(int i = 0; i<1; i++){
            int x = (int) ((int) 500*Math.random())+100;
            int y = (int) ((int) 400*Math.random());
            enemyArray.add(new Boss(x, y, 200, 10, 5, 20));
        }
    }
    @Override
    public int determineLaserStartX(int goalX, int startX){
        if(startX-goalX<100){
            return startX+100;
        }
        else{
            return startX;
        }
    }
    @Override
    public int determineLaserStartY(int goalY, int startY){
        if(startY-goalY<100){
            return startY+100;
        }
        else{
            return startY;
        }
    }
    @Override
    public void drawEnemies(Graphics g, ArcadeDemo demo){
        for(int i = 0; i<enemyArray.size(); i++){
            g.drawImage(demo.boss, enemyArray.get(i).getX(), enemyArray.get(i).getY(), demo);
            enemyArray.get(0).move();
        }
        
            
        
    }
    
}
