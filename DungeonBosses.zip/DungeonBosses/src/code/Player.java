package code;
import java.awt.Rectangle;
public class Player{
    private int x = 350;
    private int y = 650;
    private double laserDamage;
    public Rectangle hitbox = new Rectangle(350,650,50,50);
    public int hp;
    public int maxHp;
    public int speed = 3;

    public Player(){
        laserDamage = 1;
        hp =20;
        maxHp = 20;

    }
    public Player(double  damage, int hp, int speed){
        laserDamage = damage;
        this.hp = hp;
        this.maxHp =hp;
        this.speed = speed;

    }
    //returns laser damage
    public double getLaserDamage() {
        return this.laserDamage;
    }
//sets laser damage
    public void setLaserDamage(double laserDamage) {
        this.laserDamage = laserDamage;
    }
//returns x position
    public int getX(){
        return x;
    }
    //returns y position
    public int getY(){
        return y;
    }
    // sets x position
    public void setX(int x){
        this.x=x;
        this.hitbox.x=x;
        
    }
    //sets y position
    public void setY(int y){
        this.y=y;
        this.hitbox.y=y;
        
    }
    //moves up
    public void moveUp(){
        
        y -= speed;
        hitbox.y-=speed;
        if(y<0){
            y=0;
            hitbox.y =0;
        }
    }
    // moves down
    public void moveDown(){
        y+=speed;
        hitbox.y+=speed;
        if(y>650){
            y=650;
            hitbox.y =650;
        }
    }
    // moves left
    public void moveLeft(){
        x-=speed;
        hitbox.x-=speed;
        if(x<0){
            x=0;
            hitbox.x = 0;
        }
    }
    //moves right
    public void moveRight(){
        x+=speed;
        hitbox.x+=speed;
        if(x>650){
            x=650;
            hitbox.x=650;
        }
    }



}
