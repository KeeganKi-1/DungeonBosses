package code;

public class Player{
    private int x = 350;
    private int y = 650;
    private int laserDamage = 1;

    public int getLaserDamage() {
        return this.laserDamage;
    }

    public void setLaserDamage(int laserDamage) {
        this.laserDamage = laserDamage;
    }

    public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }
    private int speed = 3;
    public void moveUp(){
        y -= speed;
    }
    public void moveDown(){
        y+=speed;
    }
    public void moveLeft(){
        x-=speed;
    }
    public void moveRight(){
        x+=speed;
    }



}
