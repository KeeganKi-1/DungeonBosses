package code;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class OneUp extends Room1 {

    public OneUp(ArcadeDemo demo){
        demo.giveOneUp = true;
    }

    public boolean getsOneUp(Graphics g, ArcadeDemo demo){
        
        g.setColor(Color.RED);
        g.fillRect(250, 250, 100, 100);
        if(demo.player.hitbox.intersects(new Rectangle(250, 250, 100, 100))){
            return true;
        }
        return false;

    }

    @Override
    public void determineItemsAndPrices() {
        
    }
    @Override
    public void fillEnemies() {
        
    }
    
    @Override
    public void drawEnemies(Graphics g, ArcadeDemo demo) {
        
    }
    @Override
    public void fireEnemyLasers(ArcadeDemo demo) {
        
    }
    
}
