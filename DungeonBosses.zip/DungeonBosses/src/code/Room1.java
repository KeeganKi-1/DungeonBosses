package code;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.util.ArrayList;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JPanel;

public class Room1{
    
    ArrayList<Enemy> enemyArray = new ArrayList<Enemy>();

    public Room1(){
        
        for(int i = 0; i<5; i++){
            int x = (int) ((int) 650*Math.random());
        int y = (int) ((int) 400*Math.random());
            enemyArray.add(new Enemy(x, y, 5, 2, 2, 6));
        }
    }

    public void drawEnemies(Graphics g, ArcadeDemo demo){
        for(int i = 0; i<enemyArray.size(); i++){
            g.drawImage(demo.lvl1Enemy, enemyArray.get(i).getX(), enemyArray.get(i).getY(), demo);
        }
    }
    public int determineLaserStartX(int goalX, int startX){
        if(startX-goalX<50){
            return startX+50;
        }
        else{
            return startX;
        }
    }
    public int determineLaserStartY(int goalY, int startY){
        if(startY-goalY<50){
            return startY+50;
        }
        else{
            return startY;
        }
    }

    public void fireEnemyLasers(ArcadeDemo demo){
       
        Enemy one = enemyArray.get((int)((enemyArray.size()-1)*Math.random()));
        Enemy two = enemyArray.get((int)((enemyArray.size()-1)*Math.random()));

    
        int startX1 = determineLaserStartX(demo.player.getX(), one.getX());
        int startX2 = determineLaserStartX(demo.player.getX(), two.getX());
        int startY1 = determineLaserStartX(demo.player.getY(), one.getY());
        int startY2 = determineLaserStartX(demo.player.getY(), two.getY());
        int xVelocity = (int) ((int) one.laserSpeed*Math.cos(Math.atan2((demo.player.getY()+25)-startY1, (demo.player.getX()+25)-startX1)));
            int yVelocity = (int) ((int) one.laserSpeed*Math.sin(Math.atan2((demo.player.getY()+25)-startY1, (demo.player.getX()+25)-startX1)));
            AlienProjectile tempProj = new AlienProjectile(one.getLaserDamage());
            tempProj.fireWeapon(startX1+xVelocity,startY1+yVelocity,xVelocity,yVelocity);
            demo.laserArray.add(tempProj);

            int xVelocity2 = (int) ((int) two.laserSpeed*Math.cos(Math.atan2((demo.player.getY()+25)-startY2, (demo.player.getX()+25)-startX2)));
            int yVelocity2 = (int) ((int) two.laserSpeed*Math.sin(Math.atan2((demo.player.getY()+25)-startY2, (demo.player.getX()+25)-startX2)));
            AlienProjectile tempProj2 = new AlienProjectile(two.getLaserDamage());
            tempProj2.fireWeapon(startX2+xVelocity2,startY2+yVelocity2,xVelocity2,yVelocity2);
            demo.laserArray.add(tempProj2);
    }




}
